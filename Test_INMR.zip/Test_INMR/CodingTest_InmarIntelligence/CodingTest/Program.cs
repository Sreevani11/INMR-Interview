﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PractcePrograms
{
    public class Program
    {
        #region % operator 
        static void Main(string[] args)
        {
            Console.WriteLine("PLease enter a Number :");
            int Number = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }
        }
        #endregion

        #region Reverse of a string 

        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();
        string reversed = ReverseString(input);

        Console.WriteLine("Reversed string: " + reversed);

    static string ReverseString(string input)
    {
        char[] charArray = input.ToCharArray();
        int left = 0;
        int right = charArray.Length - 1;

        while (left < right)
        {
            // Swap characters at the left and right positions
            char temp = charArray[left];
            charArray[left] = charArray[right];
            charArray[right] = temp;

            // Move the pointers towards the center
            left++;
            right--;
        }

        return new string(charArray);
    }
}
}