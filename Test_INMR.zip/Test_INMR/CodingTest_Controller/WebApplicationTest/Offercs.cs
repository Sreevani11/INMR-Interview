﻿namespace WebApplicationTest
{
    public class Offercs
    {
        public string OfferName { get; set; }
        public List<Product> ProdCollection { get; set; }
    }
}
