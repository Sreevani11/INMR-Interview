﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

public class OfferController 
{
    private readonly OfferService _offerService;

    public OfferController(OfferService offerService)
    {
        _offerService = offerService;
    }

    // Step 3: Get today's offers
    [HttpGet]
    public async Task<HttpResponseMessage> GetTodaysOffers()
    {
        var offers = _offerService.GetTodaysOffers();
        return Ok(offers);
    }

    // Step 4: Get 3 products with the lowest prices
    [HttpGet]
    public async Task<HttpResponseMessage> GetCheapestProducts()
    {
        var products = _offerService.GetAllProducts();
        var cheapestProducts = products.OrderBy(p => p.Price).Take(3).ToList();
        return Ok(cheapestProducts);
    }

    // Step 5: Get the product with the 2nd lowest price
    [HttpGet]
    public async Task<HttpResponseMessage> GetSecondCheapestProduct()
    {
        var products = _offerService.GetAllProducts();
        var secondCheapestProduct = products.OrderBy(p => p.Price).Skip(1).FirstOrDefault();
        return Ok(secondCheapestProduct);
    }

    // Step 6: Add a new product
    [HttpPost]
    public async Task<HttpResponseMessage> AddProduct(Product newProduct)
    {
        // Assuming you have a Product model class for input data
        // You can add validation and other checks as needed
        _offerService.AddProduct(newProduct);
        return Ok("Product added successfully.");
    }
}